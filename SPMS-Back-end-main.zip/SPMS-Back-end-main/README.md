# elysee-dukachallenge

How to install
---------------
1. You Install jdk 11 in your environment
2. git clone thi repository https://github.com/nellyganza/elysee-dukachallenge.git
 ==>  in your cmd or terminal run `git clone https://github.com/nellyganza/elysee-dukachallenge.git`
   
3. navigate into DukaChallenge folder
 ==> if your using windows run `mvn.cmd spring-boot:run`
   
 ==> if you are using linux based or mac run `./mvnw spring-boot:run`
 

Steps to run docker
------------------

1. Make you sure you have docker running in your environment

2. In main directory which Dukachallenge 
   run `docker-compose up`
   
API Documentation 
------------------

link http:localhost:9092/swagger-ui.html# SPMS-Back-end
# SPMS-Back-end
