package org.auca.webtech.spms.domain;

public enum EGenre {
	LEGGE,POP,RNB,GOSPEL,CLASSIC,JAZZ,ROCK,SLOW_COUNTRY
}
