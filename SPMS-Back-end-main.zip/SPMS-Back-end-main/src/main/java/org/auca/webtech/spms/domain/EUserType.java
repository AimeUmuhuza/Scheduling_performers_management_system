package org.auca.webtech.spms.domain;

public enum EUserType {
	ADMIN,ARTIST,MANAGER
}
