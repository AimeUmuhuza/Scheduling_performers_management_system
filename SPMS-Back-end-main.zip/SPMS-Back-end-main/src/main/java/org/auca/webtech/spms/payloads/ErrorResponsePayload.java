package org.auca.webtech.spms.payloads;

public class ErrorResponsePayload {
}
